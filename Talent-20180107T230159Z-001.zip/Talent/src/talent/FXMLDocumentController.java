/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package talent;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import entity.School;
import entity.Talent;
import entity.TalentForeign;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.StageStyle;
import org.controlsfx.dialog.Dialog;
import org.controlsfx.dialog.Dialogs;

/**
 *
 * @author Touba
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private JFXTextField name;
    @FXML
    private JFXTextField firstname;
    @FXML
    private JFXTextField age;
    @FXML
    private JFXTextField level;
    @FXML
    private JFXTextField specialization;
    @FXML
    private JFXComboBox<String> type;
    @FXML
    private TableView<Talent> table;
    @FXML
    private TableColumn<Talent, String> tname;
    @FXML
    private TableColumn<Talent, String> tfirstname;
    @FXML
    private TableColumn<Talent, Integer> tage;
    @FXML
    private TableColumn<Talent, Integer> tlevel;
    @FXML
    private TableColumn<Talent, String> tspecialization;
    
    ObservableList<String> allType;
    
    ObservableList<Talent> allTalent;
    
    School school;
    
    ArrayList<Talent> talents;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        /*First Step create and set an list of our items*/
        allType = FXCollections.observableArrayList();
        allType.add("national");
        allType.add("Foreign");
        type.setItems(allType);
        
        /*Creating an school instance*/
        talents = new ArrayList<>();
        school = new School(talents);
        
        /*For the table that display all Talent*/
        allTalent = FXCollections.observableArrayList(school.getTalents());
        tname.setCellValueFactory(new PropertyValueFactory<>("name"));
        tfirstname.setCellValueFactory(new PropertyValueFactory<>("firstname"));
        tage.setCellValueFactory(new PropertyValueFactory<>("age"));
        tlevel.setCellValueFactory(new PropertyValueFactory<>("level"));
        tspecialization.setCellValueFactory(new PropertyValueFactory<>("specialization"));
        table.setItems(allTalent);
    }

    @FXML
    private void ajouter(ActionEvent event) {
        int ag=0, le=0, i=0;
        String na = name.getText();
        String fi = firstname.getText();
        String ty = type.getValue();
        try {
            ag = Integer.parseInt(age.getText());
            le = Integer.parseInt(level.getText());
        } catch (Exception e) {
            i = 1;
        }
        String sp = specialization.getText();
        if(na==null || fi == null || sp == null || i==1){
            showInformation("Error","Please fill the form Correctly");
            i=0;
        }else{
            school.addTalent(new Talent(na,fi,ag,le,sp));
            allTalent.setAll(school.getTalents());
            table.refresh();
            /*clear the form field*/
            name.setText("");
            firstname.setText("");
            age.setText("");
            level.setText("");
            specialization.setText("");
        }
    }

    @FXML
    private void supprimer(ActionEvent event) {
        try {
            int t = table.getSelectionModel().getSelectedIndex();
            school.getTalents().remove(t);
            allTalent.setAll(school.getTalents());
            table.refresh();
        } catch (Exception e) {
            showInformation("Error","Please select the element to remove");
        }
    }

    @FXML
    private void editer(ActionEvent event) {
        Talent t = table.getSelectionModel().getSelectedItem();
        t.setName(name.getText());
        t.setFirstname(firstname.getText());
        t.setAge(Integer.parseInt(age.getText()));
        t.setLevel(Integer.parseInt(level.getText()));
        t.setSpecialization(specialization.getText());
        if(t instanceof TalentForeign)
            ((TalentForeign) t).setCountry(type.getValue());
        table.refresh();
    }

    @FXML
    private void showInfo(MouseEvent event) {
        Talent t = table.getSelectionModel().getSelectedItem();
        name.setText(t.getName());
        firstname.setText(t.getFirstname());
        age.setText(t.getAge()+"");
        level.setText(t.getLevel()+"");
        specialization.setText(t.getSpecialization());
        if(t instanceof TalentForeign){
            type.setValue(((TalentForeign) t).getCountry());
        }
    }
     public static void showInformation(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initStyle(StageStyle.UTILITY);
        alert.setTitle("Information");
        alert.setHeaderText(title);
        alert.setContentText(message);

        alert.showAndWait();
    }
}
