/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.ArrayList;

/**
 *
 * @author Touba
 */
public class School {
    private ArrayList<Talent> talents;
    private static int nbrOfTalents;

    public School(ArrayList<Talent> talents) {
        this.talents = talents;
    }

    public ArrayList<Talent> getTalents() {
        return talents;
    }

    public void setTalents(ArrayList<Talent> talents) {
        this.talents = talents;
    }

    public static int getNbrOfTalents() {
        return nbrOfTalents;
    }

    public static void setNbrOfTalents(int nbrOfTalents) {
        School.nbrOfTalents = nbrOfTalents;
    }
    public void addTalent(Talent t){
        talents.add(t);
    }
}
