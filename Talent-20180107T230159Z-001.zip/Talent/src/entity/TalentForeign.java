/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Touba
 */
public class TalentForeign extends Talent{
    private String country;

    public TalentForeign(String name, String firstname, int age, int level, String specialization, String country) {
        super(name, firstname, age, level, specialization);
        this.country = country;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
    @Override
    public String print(){
        return "Foreign Talent";
    }
    
    
}
