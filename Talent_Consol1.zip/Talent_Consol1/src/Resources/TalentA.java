package Resources;

public class TalentA {

	protected String fastName, lastName, level, specializationCourse, pays;
	int age;

	public TalentA(String fastName, String lastName, String level, String specializationCourse, int age) {
		this.fastName = fastName;
		this.lastName = lastName;
		this.level = level;
		this.specializationCourse = specializationCourse;
		this.age = age;
	}

	public TalentA(String fastName, String lastName, String level, String specializationCourse, int age, String pays) {
		this(fastName, lastName, level, specializationCourse, age);
		this.pays = pays;
	}

	public String getFastName() {
		return fastName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getLevel() {
		return level;
	}

	public String getSpecializationCourse() {
		return specializationCourse;
	}

	public int getAge() {
		return age;
	}

	public String getPays() {
		return pays;
	}

	public void afficheNational() {
		System.out.println("NOM:" + fastName + "\n" + "PRENOM:" + lastName + "\n" + "AGE:" + age + "\n" + "LEVEL:"
				+ level + "\n" + "SPECIALISATION:" + specializationCourse);
	}

	public void afficheEtranger() {
		System.out.println("NOM:" + fastName + "\n" + "PRENOM:" + lastName + "\n" + "AGE:" + age + "\n" + "LEVEL:"
				+ level + "\n" + "SPECIALISATION:" + specializationCourse + "\n" + "PAYS;" + pays);
	}

}
