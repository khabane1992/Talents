package Resources;

public class Ecole {
	TalentA[] talents;
	static int maxTalent = 100;
	int nbTalent=0;

	public Ecole(TalentA[] talents) {
		this.talents = talents;
	}
	public void ajoutTalent(TalentA t){
		talents = new TalentA[maxTalent];
		if(nbTalent == maxTalent)
			System.out.println("Tableau est plein!!! L'ajout d'un nouveau �tudiant est impossible");
		else if(nbTalent<(maxTalent))
		{
			(talents[nbTalent])=t;			
			nbTalent++;			
		}
	}
	
	public static void afficheTalent (Ecole p)
	{
		
		for(int i=0;i<p.maxTalent;i++)
		{
			if(((p.talents[i]).pays)!=null)
				(p.talents[i]).afficheEtranger();
			else
				(p.talents[i]).afficheNational();
				
		}
	}
	
}
