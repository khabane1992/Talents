package Resources;

public class ClassTest {

	public static void main(String[] args) {
		
		TalentA t = new TalentA("khabane", "DIA", "M2", "java", 25);
		TalentA ts = new TalentA("khabane", "DIA", "M2", "java", 25,"togo");
		TalentA []tab = new TalentA[10];
		Ecole ec = new Ecole(tab);
		ec.ajoutTalent(ts);
		ec.ajoutTalent(t);
		Ecole.afficheTalent(ec);
	}
}
