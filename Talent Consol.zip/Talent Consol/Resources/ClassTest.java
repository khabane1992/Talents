package Resources;

public class ClassTest {

	public static void main(String[] args) {
		
		Talent t = new Talent("khabane", "DIA", "M2", "java", 25);
		TalentForeign ts = new TalentForeign("khabane", "DIA", "M2", "java", 25,"togo");
		Talent []tab = new Talent[10];
		Ecole ec = new Ecole(tab);
		ec.ajoutTalent(ts);
		ec.ajoutTalent(t);
	}
}
