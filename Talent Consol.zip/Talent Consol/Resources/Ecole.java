package Resources;

public class Ecole {
	Talent[] talents;
	static int maxTalent = 100;
	int nbTalent=0;

	public Ecole(Talent[] talents) {
		this.talents = talents;
	}
	public void ajoutTalent(Talent t){
		talents = new Talent[maxTalent];
		if(nbTalent == maxTalent)
			System.out.println("Tableau est plein!!! L'ajout d'un nouveau �tudiant est impossible");
		else if(nbTalent<(maxTalent))
		{
			(talents[nbTalent])=t;			
			nbTalent++;			
		}
	}
	
}
