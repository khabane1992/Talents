package Resources;

public class Talent {

	protected String fastName, lastName, level, specializationCourse;
	int age;

	public Talent(String fastName, String lastName, String level, String specializationCourse, int age) {
		super();
		this.fastName = fastName;
		this.lastName = lastName;
		this.level = level;
		this.specializationCourse = specializationCourse;
		this.age = age;
	}

	public String getFastName() {
		return fastName;
	}

	public void setFastName(String fastName) {
		this.fastName = fastName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getSpecializationCourse() {
		return specializationCourse;
	}

	public void setSpCours(String specializationCourse) {
		this.specializationCourse = specializationCourse;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void affiche() {
		System.out.println("NOM:" + fastName + "\n" + "PRENOM:" + lastName + "\n" + "AGE:" + age + "\n" + "LEVEL:"
				+ level + "\n" + "SPECIALISATION:" + specializationCourse);
	}

}
