package Resources;

public class TalentForeign extends Talent {

	protected String pays;

	TalentForeign(String fastName, String lastName, String level, String spCours, int age, String pays) {
		super(fastName, lastName, level, spCours, age);
		this.pays = pays;
	}

	public String getPays() {
		return pays;
	}

	public void setPays(String pays) {
		this.pays = pays;
	}
	

	public void affiche() {
		super.affiche();
		System.out.println("PAYS:"+pays);
	}
}
