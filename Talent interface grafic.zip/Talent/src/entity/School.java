/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.ArrayList;

/**
 *
 * @author Touba
 */
public class School {
    private ArrayList<TalentForeign> talents;
    private static int nbrOfTalents;

    public School(ArrayList<TalentForeign> talents) {
        this.talents = talents;
    }

    public ArrayList<TalentForeign> getTalents() {
        return talents;
    }

    public void setTalents(ArrayList<TalentForeign> talents) {
        this.talents = talents;
    }

    public static int getNbrOfTalents() {
        return nbrOfTalents;
    }

    public static void setNbrOfTalents(int nbrOfTalents) {
        School.nbrOfTalents = nbrOfTalents;
    }
    public void addTalent(TalentForeign t){
        talents.add(t);
    }
}
