/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package talent;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import entity.School;
import entity.Talent;
import entity.TalentForeign;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.StageStyle;

/**
 *
 * @author Touba
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private JFXTextField name;
    @FXML
    private JFXTextField firstname;
    @FXML
    private JFXTextField age;
    @FXML
    private JFXTextField level;
    @FXML
    private JFXTextField specialization;
    @FXML
    private JFXComboBox<String> type;
    @FXML
    private TableView<TalentForeign> table;
    @FXML
    private TableColumn<TalentForeign, String> tname;
    @FXML
    private TableColumn<TalentForeign, String> tfirstname;
    @FXML
    private TableColumn<TalentForeign, Integer> tage;
    @FXML
    private TableColumn<TalentForeign, String> tlevel;
    @FXML
    private TableColumn<TalentForeign, String> tspecialization;
    @FXML
    private TableColumn<TalentForeign, String> country;
    
    /*List of items for the combo*/
    ObservableList<String> allType;
    
    /*List for the table*/
    ObservableList<TalentForeign> allTalent;
    
    School school;
    
    /*For the school instance*/
    ArrayList<TalentForeign> talents;
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        /*First Step create and set an list of our items*/
        allType = FXCollections.observableArrayList();
        allType.add("Sénégal (national)");
        allType.add("Mali");
        allType.add("Mauritanie");
        allType.add("Niger");
        allType.add("Burkina Fasso");
        allType.add("Maroc");
        allType.add("France");
        type.setItems(allType);
        
        /*Creating an school instance*/
        talents = new ArrayList<>();
        school = new School(talents);
        
        /*For the table that display all Talent*/
        allTalent = FXCollections.observableArrayList(school.getTalents());
        tname.setCellValueFactory(new PropertyValueFactory<>("name"));
        tfirstname.setCellValueFactory(new PropertyValueFactory<>("firstname"));
        tage.setCellValueFactory(new PropertyValueFactory<>("age"));
        tlevel.setCellValueFactory(new PropertyValueFactory<>("level"));
        tspecialization.setCellValueFactory(new PropertyValueFactory<>("specialization"));
        country.setCellValueFactory(new PropertyValueFactory<>("country"));
        table.setItems(allTalent);
    }

    @FXML
    private void ajouter(ActionEvent event) {
        int ag=0, i=0;
        String na = name.getText();
        String fi = firstname.getText();
        String ty = type.getValue();
        String  le = level.getText();
        try {
            ag = Integer.parseInt(age.getText());
        } catch (Exception e) {
            i = 1;
        }
        String sp = specialization.getText();
        if(na==null || fi == null || sp == null || le == null || i==1){
            showInformation("Error","Please fill the form Correctly");
            i=0;
        }else{
            school.addTalent(new TalentForeign(na,fi,ag,le,sp,ty));
            allTalent.setAll(school.getTalents());
            table.refresh();
            /*clear the form field*/
            name.setText("");
            firstname.setText("");
            age.setText("");
            level.setText("");
            specialization.setText("");
        }
    }

    @FXML
    private void supprimer(ActionEvent event) {
        try {
            int t = table.getSelectionModel().getSelectedIndex();
            school.getTalents().remove(t);
            allTalent.setAll(school.getTalents());
            table.refresh();
        } catch (Exception e) {
            showInformation("Error","Please select the element to remove");
        }
    }

    @FXML
    private void editer(ActionEvent event) {
        TalentForeign t = table.getSelectionModel().getSelectedItem();
        t.setName(name.getText());
        t.setFirstname(firstname.getText());
        t.setAge(Integer.parseInt(age.getText()));
        t.setLevel(level.getText());
        t.setSpecialization(specialization.getText());
        t.setCountry(type.getValue());
        table.refresh();
    }

    @FXML
    private void showInfo(MouseEvent event) {
        TalentForeign t = table.getSelectionModel().getSelectedItem();
        name.setText(t.getName());
        firstname.setText(t.getFirstname());
        age.setText(t.getAge()+"");
        level.setText(t.getLevel()+"");
        specialization.setText(t.getSpecialization());
        type.setValue(t.getCountry());
    }
     public static void showInformation(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initStyle(StageStyle.UTILITY);
        alert.setTitle("Information");
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
